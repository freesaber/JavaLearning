# 慕课网Docker DevOps课程源码

本代码仓库会不定期进行更新。请大家关注。

**大家遇到问题请不要在此代码仓库里提issue，请在慕课网课程问答区提问，谢谢**


大家如果发现任何错误，可以在慕课网问答区提问，或者直接在此提交merge request，提交更改。

## 关于翻墙

本课程里部分link可能需要翻墙，大家如果自己没有VPN的话，可以尝试蓝灯

https://github.com/getlantern/forum

## 本课程的一些常用链接汇总

Vagrant下载 https://www.vagrantup.com/downloads.html

Virtualbox 5.1下载 https://www.virtualbox.org/wiki/Download_Old_Builds_5_1

Docker国内源安装 https://get.daocloud.io/#install-docker

Docker官方网站 https://www.docker.com/

Docker官方文档中心 https://docs.docker.com/

DockerHub https://hub.docker.com/

