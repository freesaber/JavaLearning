# Hacking Guide

## Code style

Step 1: Read http://www.python.org/dev/peps/pep-0008/

Step 2: Read http://www.python.org/dev/peps/pep-0008/ again

Step 3: Read on

## Running Tests

Run tox

```
$ cd skeleton
$ tox
```
