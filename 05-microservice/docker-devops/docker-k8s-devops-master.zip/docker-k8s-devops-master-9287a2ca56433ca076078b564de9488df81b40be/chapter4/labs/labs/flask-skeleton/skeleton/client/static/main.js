// custom javascript

$( document ).ready(function() {
  console.log('Sanity Check!');
});